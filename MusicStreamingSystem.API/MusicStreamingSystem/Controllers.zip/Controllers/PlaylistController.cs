﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MusicStreamingSystem.Core.DTOs.Playlist;
using MusicStreamingSystem.Data.RepositoryInterfaces;
using System.Security.Claims;

namespace MusicStreamingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PlaylistController : ControllerBase
    {
        private readonly IPlaylistRepository _playlistRepository;

        public PlaylistController(IPlaylistRepository playlistRepository)
        {
            _playlistRepository = playlistRepository;
        }

        private int UserId
        {
            get
            {
                return int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            }
        }

        #region Playlist

        [HttpGet]
        public async Task<IActionResult> GetPlaylists()
        {
            var playlists = await _playlistRepository.GetPlaylistsAsync(UserId);

            return Ok(playlists);
        }

        [HttpGet("{playlistId}")]
        public async Task<IActionResult> GetPlaylistById(int playlistId)
        {
            var playlist = await _playlistRepository.GetPlaylistByIdAsync(
                playlistId,
                UserId);

            if (playlist == null)
                return NotFound(new
                {
                    Message = "Playlist not found."
                });

            return Ok(playlist);
        }

        [HttpPost]
        public async Task<IActionResult> CreatePlaylist([FromBody] PlaylistRequest request)
        {
            await _playlistRepository.CreatePlaylistAsync(
                UserId,
                request);

            return Ok(new
            {
                Message = "Playlist created successfully."
            });
        }

        [HttpPut("{playlistId}")]
        public async Task<IActionResult> RenamePlaylist(
            int playlistId,
            [FromBody] PlaylistRequest request)
        {
            bool result = await _playlistRepository.RenamePlaylistAsync(
                playlistId,
                UserId,
                request);

            if (!result)
                return NotFound(new
                {
                    Message = "Playlist not found."
                });

            return Ok(new
            {
                Message = "Playlist updated successfully."
            });
        }

        [HttpDelete("{playlistId}")]
        public async Task<IActionResult> DeletePlaylist(int playlistId)
        {
            bool result = await _playlistRepository.DeletePlaylistAsync(
                playlistId,
                UserId);

            if (!result)
                return NotFound(new
                {
                    Message = "Playlist not found."
                });

            return Ok(new
            {
                Message = "Playlist deleted successfully."
            });
        }

        #endregion

        #region Playlist Songs

        [HttpPost("{playlistId}/songs")]
        public async Task<IActionResult> AddSong(
            int playlistId,
            [FromBody] AddSongRequest request)
        {
            bool result = await _playlistRepository.AddSongAsync(
                playlistId,
                UserId,
                request.SongId);

            if (!result)
                return BadRequest(new
                {
                    Message = "Unable to add song to playlist."
                });

            return Ok(new
            {
                Message = "Song added successfully."
            });
        }

        [HttpDelete("{playlistId}/songs/{songId}")]
        public async Task<IActionResult> RemoveSong(
            int playlistId,
            int songId)
        {
            bool result = await _playlistRepository.RemoveSongAsync(
                playlistId,
                UserId,
                songId);

            if (!result)
                return NotFound(new
                {
                    Message = "Song not found in playlist."
                });

            return Ok(new
            {
                Message = "Song removed successfully."
            });
        }

        #endregion
    }
}