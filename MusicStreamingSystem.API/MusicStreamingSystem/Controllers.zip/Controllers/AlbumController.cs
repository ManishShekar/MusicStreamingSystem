﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MusicStreamingSystem.Core.DTOs.Album;
using MusicStreamingSystem.Data.RepositoryInterfaces;
using MusicStreamingSystem.Utilities.FileUpload;

namespace MusicStreamingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumController : ControllerBase
    {
        private readonly IAlbumRepository _albumRepository;
        private readonly FileService _fileService;
        private readonly IWebHostEnvironment _environment;

        public AlbumController(
            IAlbumRepository albumRepository,
            FileService fileService,
            IWebHostEnvironment environment)
        {
            _albumRepository = albumRepository;
            _fileService = fileService;
            _environment = environment;
        }

        [HttpGet("{artistId}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAlbumsByArtist(int artistId)
        {
            var albums = await _albumRepository.GetAlbumsByArtistAsync(artistId);

            return Ok(albums);
        }

        [HttpGet("details/{albumId}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAlbumById(int albumId)
        {
            var album = await _albumRepository.GetAlbumByIdAsync(albumId);

            if (album == null)
                return NotFound();

            return Ok(album);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddAlbum([FromForm] AlbumRequest request)
        {
            if (request.CoverImage == null)
                return BadRequest("Album cover image is required.");

            string folderPath = Path.Combine(
                _environment.ContentRootPath,
                "wwwroot",
                "Uploads",
                "Albums");

            string fileName = await _fileService.UploadFile(
                request.CoverImage,
                folderPath);

            string coverImageUrl = "/Uploads/Albums/" + fileName;

            await _albumRepository.AddAlbumAsync(
                request.Title,
                request.ArtistId,
                request.ReleaseYear,
                coverImageUrl);

            return Ok(new
            {
                Message = "Album added successfully."
            });
        }

        [HttpDelete("{albumId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteAlbum(int albumId)
        {
            bool result = await _albumRepository.DeleteAlbumAsync(albumId);

            if (!result)
                return NotFound();

            return Ok(new
            {
                Message = "Album deleted successfully."
            });
        }
    }
}