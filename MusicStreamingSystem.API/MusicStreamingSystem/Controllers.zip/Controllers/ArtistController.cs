﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MusicStreamingSystem.Core.DTOs.Artist;
using MusicStreamingSystem.Data.RepositoryInterfaces;
using MusicStreamingSystem.Utilities.FileUpload;

namespace MusicStreamingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistController : ControllerBase
    {
        private readonly IArtistRepository _artistRepository;
        private readonly FileService _fileService;
        private readonly IWebHostEnvironment _environment;

        public ArtistController(
            IArtistRepository artistRepository,
            FileService fileService,
            IWebHostEnvironment environment)
        {
            _artistRepository = artistRepository;
            _fileService = fileService;
            _environment = environment;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllArtists()
        {
            var artists = await _artistRepository.GetAllArtistsAsync();

            return Ok(artists);
        }

        [HttpGet("{artistId}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetArtistById(int artistId)
        {
            var artist = await _artistRepository.GetArtistByIdAsync(artistId);

            if (artist == null)
                return NotFound();

            return Ok(artist);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddArtist([FromForm] ArtistRequest request)
        {
            if (request.Image == null)
                return BadRequest("Artist image is required.");

            string folderPath = Path.Combine(
                _environment.WebRootPath,
                "Uploads",
                "Artists");

            string fileName = await _fileService.UploadFile(
                request.Image,
                folderPath);

            string imageUrl = "/Uploads/Artists/" + fileName;

            await _artistRepository.AddArtistAsync(
                request.ArtistName,
                imageUrl);

            return Ok(new
            {
                Message = "Artist added successfully."
            });
        }

        [HttpDelete("{artistId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteArtist(int artistId)
        {
            bool result = await _artistRepository.DeleteArtistAsync(artistId);

            if (!result)
                return NotFound();

            return Ok(new
            {
                Message = "Artist deleted successfully."
            });
        }
    }
}