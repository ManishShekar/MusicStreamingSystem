﻿using Microsoft.AspNetCore.Mvc;
using MusicStreamingSystem.Core.DTOs.Auth;
using MusicStreamingSystem.Data.RepositoryInterfaces;
using MusicStreamingSystem.Utilities.JWT;

namespace MusicStreamingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _authRepository;
        private readonly JwtTokenGenerator _jwtTokenGenerator;

        public AuthController(
            IAuthRepository authRepository,
            JwtTokenGenerator jwtTokenGenerator)
        {
            _authRepository = authRepository;
            _jwtTokenGenerator = jwtTokenGenerator;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (request.Password != request.ConfirmPassword)
            {
                return BadRequest(new
                {
                    Message = "Password and Confirm Password do not match."
                });
            }

            var result = await _authRepository.RegisterAsync(request);

            return Ok(result);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = await _authRepository.LoginAsync(request);

            if (user == null)
            {
                return Unauthorized(new
                {
                    Message = "Invalid Email or Password."
                });
            }

            user.Token = _jwtTokenGenerator.GenerateToken(
                user.UserId,
                user.UserName,
                user.Email,
                user.Role);

            return Ok(user);
        }
    }
}