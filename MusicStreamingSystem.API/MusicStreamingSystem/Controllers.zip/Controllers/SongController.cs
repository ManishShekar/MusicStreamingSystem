﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MusicStreamingSystem.Core.DTOs.Song;
using MusicStreamingSystem.Data.RepositoryInterfaces;

namespace MusicStreamingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SongController : ControllerBase
    {
        private readonly ISongRepository _songRepository;

        public SongController(ISongRepository songRepository)
        {
            _songRepository = songRepository;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetSongs(
            string? search,
            int? genre)
        {
            var songs = await _songRepository.GetSongsAsync(
                search,
                genre);

            return Ok(songs);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddSong(
            SongRequest request)
        {
            await _songRepository.AddSongAsync(request);

            return Ok(new
            {
                Message = "Song Added Successfully."
            });
        }

        [HttpDelete("{songId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteSong(int songId)
        {
            var result = await _songRepository.DeleteSongAsync(songId);

            if (!result)
                return NotFound();

            return Ok(new
            {
                Message = "Song Deleted Successfully."
            });
        }
    }
}